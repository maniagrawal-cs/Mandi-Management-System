// Base URL of the backend. Change this if you run uvicorn on a different port.
const API_BASE = "http://127.0.0.1:8000";

function show(data) {
  document.getElementById("output").textContent = JSON.stringify(data, null, 2);
  return data;
}

async function callApi(path, method = "GET", body = null) {
  try {
    const options = { method, headers: { "Content-Type": "application/json" } };
    if (body) options.body = JSON.stringify(body);
    const res = await fetch(API_BASE + path, options);
    const data = await res.json();
    if (!res.ok) {
      show({ error: true, status: res.status, detail: data.detail || data });
      return null;
    }
    show(data);
    return data;
  } catch (err) {
    show({ networkError: String(err), hint: "Is the backend running at " + API_BASE + " ?" });
    return null;
  }
}

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

// ---------- Farmer ----------

async function farmerRegister() {
  const body = {
    name: document.getElementById("reg-name").value,
    mobile: document.getElementById("reg-mobile").value,
    government_id: document.getElementById("reg-govid").value,
    password: document.getElementById("reg-password").value,
  };
  await callApi("/farmer/register", "POST", body);
}

async function farmerLogin() {
  const body = {
    mobile: document.getElementById("login-mobile").value,
    password: document.getElementById("login-password").value,
  };
  const data = await callApi("/farmer/login", "POST", body);
  if (data && data.farmer) {
    document.getElementById("gp-farmer-id").value = data.farmer.farmer_id;
    document.getElementById("dash-farmer-id").value = data.farmer.farmer_id;
  }
}

async function generateGatePass() {
  const dateVal = document.getElementById("gp-date").value || todayStr();
  const body = {
    farmer_id: document.getElementById("gp-farmer-id").value,
    date: dateVal,
    estimated_weight: parseFloat(document.getElementById("gp-weight").value),
  };
  const data = await callApi("/gate-pass", "POST", body);
  if (data && data.gate_pass_id) {
    document.getElementById("scan-gate-pass-id").value = data.gate_pass_id;
  }
}

async function loadFarmerDashboard() {
  const farmerId = document.getElementById("dash-farmer-id").value;
  const data = await callApi(`/farmer/${farmerId}/dashboard`);
  const qrDiv = document.getElementById("qr-display");
  qrDiv.innerHTML = "";
  if (data && data.gate_pass && data.gate_pass.qr_url) {
    qrDiv.innerHTML = `<p><b>Gate Pass QR (${data.gate_pass.gate_pass_id}):</b></p>
      <img class="qr" src="${data.gate_pass.qr_url}" width="150" height="150">`;
  }
}

async function scanQr() {
  const body = { gate_pass_id: document.getElementById("scan-gate-pass-id").value };
  await callApi("/qr/scan", "POST", body);
}

// ---------- Officer ----------

async function officerLogin() {
  const body = {
    username: document.getElementById("officer-username").value,
    password: document.getElementById("officer-password").value,
  };
  await callApi("/officer/login", "POST", body);
}

async function loadOfficerDashboard() {
  const dateVal = document.getElementById("officer-date").value || todayStr();
  const data = await callApi(`/officer/dashboard?target_date=${dateVal}`);
  const gridDiv = document.getElementById("officer-grid");
  if (!data || !data.farmers) { gridDiv.innerHTML = ""; return; }

  let html = `<p><b>Capacity:</b> ${data.capacity.allocated_capacity} / ${data.capacity.total_capacity} kg
    (remaining ${data.capacity.remaining_capacity} kg)</p>`;
  html += "<table><tr><th>Farmer</th><th>Gate Pass</th><th>Weight</th><th>Stage</th><th>Queue Pos</th></tr>";
  for (const f of data.farmers) {
    html += `<tr>
      <td>${f.farmer_name} (${f.farmer_id})</td>
      <td>${f.gate_pass_id}</td>
      <td>${f.estimated_weight} kg</td>
      <td><span class="badge ${f.color}">${f.current_stage_label}</span></td>
      <td>${f.queue_position ?? "-"}</td>
    </tr>`;
  }
  html += "</table>";
  gridDiv.innerHTML = html;
}

async function checkCapacity() {
  const dateVal = document.getElementById("capacity-date").value || todayStr();
  await callApi(`/capacity/${dateVal}`);
}
