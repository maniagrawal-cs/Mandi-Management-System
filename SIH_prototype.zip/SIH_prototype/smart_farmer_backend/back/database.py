"""
database.py
------------
Everything related to SQLite lives here:
  1. How we connect to the database file
  2. The table definitions (schema)
  3. Small helper functions used everywhere else in the project
  4. Demo/sample data so the app is usable immediately after cloning it

We use plain SQL (no ORM) on purpose - it's easier for a beginner to read
and there is a 1-to-1 mapping between the tables described in the project
spec and the CREATE TABLE statements below.

NOTE ON COMBINING TABLES:
The original spec suggested separate `farmer_status` and `queue` tables.
We merged `farmer_status` into `gate_passes` (current_stage / previous_stage
/ stage_updated_at columns) because a gate pass and a farmer's status are
really the same "journey" for one visit. The `queue` is NOT stored as a
table at all - it is calculated on the fly from `gate_passes`
(see get_queue_info in routes.py). This avoids the two tables ever going
out of sync with each other, which is a very common bug in prototypes.
"""

import sqlite3
from datetime import date, timedelta

DB_FILE = "smart_farmer.db"


def get_connection():
    """Open a new connection to the SQLite file. Callers must close it."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  # lets us access columns by name, e.g. row["name"]
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# ---------------------------------------------------------------------------
# Small generic helpers so routes.py doesn't repeat connect/close everywhere
# ---------------------------------------------------------------------------

def fetch_one(query: str, params: tuple = ()):
    conn = get_connection()
    try:
        row = conn.execute(query, params).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def fetch_all(query: str, params: tuple = ()):
    conn = get_connection()
    try:
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def execute(query: str, params: tuple = ()):
    """For INSERT / UPDATE / DELETE. Returns the connection's lastrowid."""
    conn = get_connection()
    try:
        cur = conn.execute(query, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

def init_db():
    conn = get_connection()
    cur = conn.cursor()

    # Farmers whose identity is already "verified" through (simulated)
    # government records. Farmers can never insert a brand new row here
    # themselves - they can only "claim" an existing row during registration.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS farmers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            mobile TEXT NOT NULL,
            government_id TEXT NOT NULL,
            village TEXT,
            district TEXT,
            password TEXT DEFAULT '',   -- empty until the farmer registers/sets a password
            verified INTEGER DEFAULT 1  -- 1 = government-verified record
        )
    """)

    # Officers who operate the centre.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS officers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            centre_id TEXT
        )
    """)

    # How much storage capacity (in kg) exists per date, and how much of it
    # has already been promised to farmers via gate passes.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS centre_capacity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT UNIQUE NOT NULL,
            total_capacity REAL NOT NULL,
            allocated_capacity REAL NOT NULL DEFAULT 0
        )
    """)

    # A gate pass IS the farmer's visit/journey for a given date.
    # current_stage / previous_stage / stage_updated_at replace the separate
    # "farmer_status" table from the original spec (see note at top of file).
    cur.execute("""
        CREATE TABLE IF NOT EXISTS gate_passes (
            id TEXT PRIMARY KEY,
            farmer_id TEXT NOT NULL,
            date TEXT NOT NULL,
            estimated_weight REAL NOT NULL,
            qr_id TEXT,
            qr_url TEXT,
            status TEXT DEFAULT 'APPROVED',        -- APPROVED / USED / COMPLETED / CANCELLED
            current_stage TEXT DEFAULT 'GATE_PASS_GENERATED',
            previous_stage TEXT,
            stage_updated_at TEXT,
            arrival_time TEXT,
            created_at TEXT,
            FOREIGN KEY (farmer_id) REFERENCES farmers(id)
        )
    """)

    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Capacity helper - used by the gate-pass creation logic
# ---------------------------------------------------------------------------

DEFAULT_TOTAL_CAPACITY = 100000  # kg, used if a date has no capacity row yet


def get_or_create_capacity_row(target_date: str):
    """
    Make sure a centre_capacity row exists for this date.
    If it doesn't exist yet, create it with the default total capacity.
    """
    row = fetch_one("SELECT * FROM centre_capacity WHERE date = ?", (target_date,))
    if row:
        return row
    execute(
        "INSERT INTO centre_capacity (date, total_capacity, allocated_capacity) VALUES (?, ?, 0)",
        (target_date, DEFAULT_TOTAL_CAPACITY),
    )
    return fetch_one("SELECT * FROM centre_capacity WHERE date = ?", (target_date,))


# ---------------------------------------------------------------------------
# ID generators - simple, readable, sequential-looking IDs for the demo
# ---------------------------------------------------------------------------

def generate_gate_pass_id():
    count = fetch_one("SELECT COUNT(*) as c FROM gate_passes")["c"]
    new_id = f"GP{1001 + count}"
    # extremely unlikely, but guard against collisions if rows were deleted
    while fetch_one("SELECT id FROM gate_passes WHERE id = ?", (new_id,)):
        count += 1
        new_id = f"GP{1001 + count}"
    return new_id


# ---------------------------------------------------------------------------
# Demo data - makes the prototype usable immediately
# ---------------------------------------------------------------------------

def seed_demo_data():
    existing = fetch_one("SELECT COUNT(*) as c FROM farmers")["c"]
    if existing > 0:
        return  # already seeded, don't duplicate

    today = date.today().isoformat()
    tomorrow = (date.today() + timedelta(days=1)).isoformat()

    conn = get_connection()
    cur = conn.cursor()

    # --- Farmers (this simulates "government verified" records) ---
    # F1001 & F1003 have NOT registered yet (password is empty) -> they must
    # go through POST /farmer/register first.
    # F1002 has already registered -> can log in directly with POST /farmer/login
    cur.executemany(
        """INSERT INTO farmers (id, name, mobile, government_id, village, district, password, verified)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        [
            ("F1001", "Ram Kumar", "9990001111", "GOV1001", "Rampur", "Meerut", "", 1),
            ("F1002", "Sita Devi", "9990002222", "GOV1002", "Sonipat", "Sonipat", "pass123", 1),
            ("F1003", "Mohan Lal", "9990003333", "GOV1003", "Karnal", "Karnal", "", 1),
        ],
    )

    # --- Officers ---
    cur.execute(
        """INSERT INTO officers (id, name, username, password, centre_id)
           VALUES (?, ?, ?, ?, ?)""",
        ("O1001", "Officer Suresh", "suresh", "officer123", "CENTRE01"),
    )

    # --- Capacity ---
    # Today: 80,000 kg out of 100,000 kg already booked (matches the example
    # in the spec, so you can immediately test the "capacity full" scenario
    # by requesting >20,000 kg more for today).
    cur.execute(
        "INSERT INTO centre_capacity (date, total_capacity, allocated_capacity) VALUES (?, ?, ?)",
        (today, 100000, 80000),
    )
    cur.execute(
        "INSERT INTO centre_capacity (date, total_capacity, allocated_capacity) VALUES (?, ?, ?)",
        (tomorrow, 100000, 0),
    )

    # --- One sample gate pass already "in progress" today, so the officer
    # dashboard has something to show immediately ---
    cur.execute(
        """INSERT INTO gate_passes
           (id, farmer_id, date, estimated_weight, qr_id, qr_url, status,
            current_stage, previous_stage, stage_updated_at, arrival_time, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            "GP1001", "F1002", today, 500, "GP1001",
            "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=GP1001",
            "USED", "WEIGHT_CHECK", "ARRIVED",
            f"{today}T09:15:00", f"{today}T09:00:00", f"{today}T08:00:00",
        ),
    )

    conn.commit()
    conn.close()
