"""
main.py
-------
Entry point for the backend. Run this file (via uvicorn) to start the server.

    uvicorn main:app --reload

This file is intentionally tiny: it just creates the FastAPI app, sets up
CORS (so the test frontend can call the API from a different port/file),
makes sure the database exists on startup, and plugs in all the routes
from routes.py.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import init_db, seed_demo_data
from routes import router

app = FastAPI(
    title="Smart Farmer Gate Pass & Queue Management System",
    description="Hackathon prototype backend for farmer entry, gate passes, queueing and storage capacity.",
    version="1.0.0",
)

# Allow the test frontend (served from anywhere - file://, localhost:5500, etc.)
# to call this API. Fine for a prototype; you would restrict this in production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()
    seed_demo_data()


@app.get("/")
def root():
    return {
        "message": "Smart Farmer Gate Pass & Queue Management System backend is running.",
        "docs": "/docs",
    }


app.include_router(router)
