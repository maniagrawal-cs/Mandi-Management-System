"""
routes.py
---------
All API endpoints live here, grouped into clearly commented sections:
  1. Farmer registration & login
  2. Officer login
  3. Capacity
  4. Gate pass creation
  5. QR code
  6. Farmer dashboard / status / queue
  7. Officer dashboard

Authentication note: this is a hackathon prototype, so login simply checks
mobile/username + password against the database and returns the user's ID.
There are no JWT tokens or sessions - the frontend just remembers the
farmer_id / officer_id after login and sends it with later requests. This
is intentionally simple, as requested in the project spec.
"""

from datetime import date, datetime
from typing import Optional
from fastapi import APIRouter, HTTPException

from database import (
    fetch_one, fetch_all, execute,
    get_or_create_capacity_row, generate_gate_pass_id,
)
from models import (
    FarmerRegisterRequest, FarmerLoginRequest, OfficerLoginRequest,
    GatePassRequest, QRScanRequest, CapacitySetRequest,
)
from stages import (
    STAGE_ORDER, STAGE_COLORS, STAGE_LABELS,
    get_next_stage, get_stage_index, build_progress_timeline,
)
import qr_service

router = APIRouter()


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def today_str():
    return date.today().isoformat()


# ===========================================================================
# 1. FARMER REGISTRATION & LOGIN
# ===========================================================================

@router.post("/farmer/register")
def farmer_register(payload: FarmerRegisterRequest):
    """
    'Registration' does not create a new farmer. It matches the entered
    name + mobile number against the government-verified farmers table
    (simulated here as the `farmers` table) and, if found, sets a login
    password for that existing record.
    """
    farmer = fetch_one(
        "SELECT * FROM farmers WHERE LOWER(name) = LOWER(?) AND mobile = ?",
        (payload.name.strip(), payload.mobile.strip()),
    )

    if not farmer:
        raise HTTPException(
            status_code=404,
            detail="No government-verified farmer record matches this name and mobile number.",
        )

    if farmer["password"]:
        raise HTTPException(
            status_code=400,
            detail="This farmer is already registered. Please use /farmer/login instead.",
        )

    execute(
        "UPDATE farmers SET password = ?, verified = 1 WHERE id = ?",
        (payload.password, farmer["id"]),
    )

    return {
        "message": "Registration successful. You can now log in.",
        "farmer_id": farmer["id"],
    }


@router.post("/farmer/login")
def farmer_login(payload: FarmerLoginRequest):
    farmer = fetch_one("SELECT * FROM farmers WHERE mobile = ?", (payload.mobile.strip(),))

    if not farmer:
        raise HTTPException(status_code=404, detail="Farmer not found.")

    if not farmer["password"]:
        raise HTTPException(
            status_code=400,
            detail="This farmer has not registered yet. Please use /farmer/register first.",
        )

    if farmer["password"] != payload.password:
        raise HTTPException(status_code=401, detail="Incorrect password.")

    return build_farmer_dashboard(farmer["id"])


# ===========================================================================
# 2. OFFICER LOGIN
# ===========================================================================

@router.post("/officer/login")
def officer_login(payload: OfficerLoginRequest):
    officer = fetch_one("SELECT * FROM officers WHERE username = ?", (payload.username.strip(),))

    if not officer or officer["password"] != payload.password:
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    return {
        "officer_id": officer["id"],
        "name": officer["name"],
        "centre_id": officer["centre_id"],
    }


# ===========================================================================
# 3. CAPACITY
# ===========================================================================

@router.get("/capacity/{target_date}")
def get_capacity(target_date: str):
    row = get_or_create_capacity_row(target_date)
    remaining = row["total_capacity"] - row["allocated_capacity"]
    return {
        "date": row["date"],
        "total_capacity": row["total_capacity"],
        "allocated_capacity": row["allocated_capacity"],
        "remaining_capacity": remaining,
    }


@router.post("/capacity")
def set_capacity(payload: CapacitySetRequest):
    """Optional helper so an officer can configure how much capacity a date has."""
    row = fetch_one("SELECT * FROM centre_capacity WHERE date = ?", (payload.date,))
    if row:
        execute(
            "UPDATE centre_capacity SET total_capacity = ? WHERE date = ?",
            (payload.total_capacity, payload.date),
        )
    else:
        execute(
            "INSERT INTO centre_capacity (date, total_capacity, allocated_capacity) VALUES (?, ?, 0)",
            (payload.date, payload.total_capacity),
        )
    return get_capacity(payload.date)


# ===========================================================================
# 4. GATE PASS CREATION
# ===========================================================================

@router.post("/gate-pass")
def create_gate_pass(payload: GatePassRequest):
    farmer = fetch_one("SELECT * FROM farmers WHERE id = ?", (payload.farmer_id,))
    if not farmer:
        raise HTTPException(status_code=404, detail="Farmer not found.")

    if payload.estimated_weight <= 0:
        raise HTTPException(status_code=400, detail="Estimated weight must be greater than 0.")

    capacity = get_or_create_capacity_row(payload.date)
    remaining = capacity["total_capacity"] - capacity["allocated_capacity"]

    # --- THE CORE CAPACITY RULE FROM THE SPEC ---
    if capacity["allocated_capacity"] + payload.estimated_weight > capacity["total_capacity"]:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Storage capacity is full for {payload.date}. "
                f"Only {remaining} kg remaining, but {payload.estimated_weight} kg was requested. "
                f"Please select another date."
            ),
        )

    # Capacity is available -> reserve it, create the gate pass, generate a QR code
    gate_pass_id = generate_gate_pass_id()
    qr_url = qr_service.generate_qr_url(gate_pass_id)
    created_at = now_iso()

    execute(
        """INSERT INTO gate_passes
           (id, farmer_id, date, estimated_weight, qr_id, qr_url, status,
            current_stage, previous_stage, stage_updated_at, arrival_time, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'APPROVED', 'GATE_PASS_GENERATED', NULL, ?, NULL, ?)""",
        (gate_pass_id, farmer["id"], payload.date, payload.estimated_weight,
         gate_pass_id, qr_url, created_at, created_at),
    )

    execute(
        "UPDATE centre_capacity SET allocated_capacity = allocated_capacity + ? WHERE date = ?",
        (payload.estimated_weight, payload.date),
    )

    gate_pass = fetch_one("SELECT * FROM gate_passes WHERE id = ?", (gate_pass_id,))
    return format_gate_pass(gate_pass, farmer)


@router.get("/gate-pass/{gate_pass_id}")
def get_gate_pass(gate_pass_id: str):
    gate_pass = fetch_one("SELECT * FROM gate_passes WHERE id = ?", (gate_pass_id,))
    if not gate_pass:
        raise HTTPException(status_code=404, detail="Gate pass not found.")
    farmer = fetch_one("SELECT * FROM farmers WHERE id = ?", (gate_pass["farmer_id"],))
    return format_gate_pass(gate_pass, farmer)


def format_gate_pass(gate_pass: dict, farmer: dict):
    return {
        "gate_pass_id": gate_pass["id"],
        "farmer_id": gate_pass["farmer_id"],
        "farmer_name": farmer["name"] if farmer else None,
        "date": gate_pass["date"],
        "estimated_weight": gate_pass["estimated_weight"],
        "status": gate_pass["status"],
        "current_stage": gate_pass["current_stage"],
        "current_stage_label": STAGE_LABELS.get(gate_pass["current_stage"], gate_pass["current_stage"]),
        "qr_url": gate_pass["qr_url"],
        "created_at": gate_pass["created_at"],
    }


# ===========================================================================
# 5. QR CODE - fetch & scan
# ===========================================================================

@router.get("/gate-pass/{gate_pass_id}/qr")
def get_qr_code(gate_pass_id: str):
    gate_pass = fetch_one("SELECT * FROM gate_passes WHERE id = ?", (gate_pass_id,))
    if not gate_pass:
        raise HTTPException(status_code=404, detail="Gate pass not found.")
    return {"gate_pass_id": gate_pass_id, "qr_url": gate_pass["qr_url"]}


@router.post("/qr/scan")
def scan_qr(payload: QRScanRequest):
    """
    This is the heart of the "automatic stage progression" requirement.
    An officer/machine scans a QR code -> the text inside it (the gate pass
    ID) is sent here -> we move the farmer to the NEXT stage in STAGE_ORDER.
    The officer never manually picks a stage; the backend decides it.
    """
    gate_pass = fetch_one("SELECT * FROM gate_passes WHERE id = ?", (payload.gate_pass_id,))

    # 1 & 2. Find the gate pass & verify it exists
    if not gate_pass:
        raise HTTPException(status_code=404, detail="Invalid QR code. Gate pass not found.")

    # 3. Verify it is valid (not cancelled)
    if gate_pass["status"] == "CANCELLED":
        raise HTTPException(status_code=400, detail="This gate pass has been cancelled.")

    current_stage = gate_pass["current_stage"]

    # 5. Verify it has not already been fully used
    if current_stage == "COMPLETED":
        raise HTTPException(
            status_code=400,
            detail="This farmer's process is already completed. QR code cannot be scanned again.",
        )

    # 4. Verify the arrival date - only matters for the FIRST scan (actual arrival)
    if current_stage == "GATE_PASS_GENERATED" and gate_pass["date"] != today_str():
        raise HTTPException(
            status_code=400,
            detail=f"This gate pass is valid for {gate_pass['date']}, not today ({today_str()}).",
        )

    next_stage = get_next_stage(current_stage)
    if not next_stage:
        raise HTTPException(status_code=400, detail="There is no further stage to move to.")

    timestamp = now_iso()
    arrival_time = gate_pass["arrival_time"]
    if current_stage == "GATE_PASS_GENERATED":
        # This scan IS the arrival event
        arrival_time = timestamp

    new_status = "COMPLETED" if next_stage == "COMPLETED" else "USED"

    execute(
        """UPDATE gate_passes
           SET previous_stage = ?, current_stage = ?, stage_updated_at = ?,
               arrival_time = ?, status = ?
           WHERE id = ?""",
        (current_stage, next_stage, timestamp, arrival_time, new_status, gate_pass["id"]),
    )

    # 6 & 7. Identify farmer, return updated info (queue is recalculated live)
    updated_gate_pass = fetch_one("SELECT * FROM gate_passes WHERE id = ?", (gate_pass["id"],))
    farmer = fetch_one("SELECT * FROM farmers WHERE id = ?", (gate_pass["farmer_id"],))
    queue_info = get_queue_info(updated_gate_pass)

    return {
        "message": f"Farmer moved from {current_stage} to {next_stage}.",
        "gate_pass": format_gate_pass(updated_gate_pass, farmer),
        "farmer_name": farmer["name"],
        "previous_stage": current_stage,
        "current_stage": next_stage,
        "queue": queue_info,
    }


# ===========================================================================
# 6. FARMER DASHBOARD / STATUS / QUEUE
# ===========================================================================

def get_latest_gate_pass_for_farmer(farmer_id: str):
    """A farmer could technically have multiple gate passes over time; we show the newest one."""
    return fetch_one(
        "SELECT * FROM gate_passes WHERE farmer_id = ? ORDER BY created_at DESC LIMIT 1",
        (farmer_id,),
    )


def get_queue_info(gate_pass: dict):
    """
    Queue is calculated LIVE, not stored in its own table.
    "In the queue" = farmers who have arrived (current_stage is past
    GATE_PASS_GENERATED) but have not finished (current_stage != COMPLETED)
    for the same date, ordered by when they actually arrived.
    """
    if gate_pass["current_stage"] == "GATE_PASS_GENERATED":
        return {
            "in_queue": False,
            "message": "You have not arrived at the centre yet.",
            "position": None,
            "farmers_ahead": None,
            "farmers_waiting_total": None,
        }

    if gate_pass["current_stage"] == "COMPLETED":
        return {
            "in_queue": False,
            "message": "Your process is complete.",
            "position": None,
            "farmers_ahead": None,
            "farmers_waiting_total": None,
        }

    waiting_farmers = fetch_all(
        """SELECT id, arrival_time FROM gate_passes
           WHERE date = ? AND current_stage NOT IN ('GATE_PASS_GENERATED', 'COMPLETED')
           ORDER BY arrival_time ASC""",
        (gate_pass["date"],),
    )

    ids_in_order = [row["id"] for row in waiting_farmers]
    position = ids_in_order.index(gate_pass["id"]) + 1 if gate_pass["id"] in ids_in_order else None

    return {
        "in_queue": True,
        "position": position,
        "farmers_ahead": (position - 1) if position else None,
        "farmers_waiting_total": len(ids_in_order),
    }


def build_farmer_dashboard(farmer_id: str):
    farmer = fetch_one("SELECT * FROM farmers WHERE id = ?", (farmer_id,))
    if not farmer:
        raise HTTPException(status_code=404, detail="Farmer not found.")

    gate_pass = get_latest_gate_pass_for_farmer(farmer_id)

    result = {
        "farmer": {
            "farmer_id": farmer["id"],
            "name": farmer["name"],
            "village": farmer["village"],
            "district": farmer["district"],
            "verified": bool(farmer["verified"]),
        },
        "gate_pass": None,
        "progress_timeline": None,
        "queue": None,
    }

    if gate_pass:
        result["gate_pass"] = format_gate_pass(gate_pass, farmer)
        result["progress_timeline"] = build_progress_timeline(gate_pass["current_stage"])
        result["queue"] = get_queue_info(gate_pass)

    return result


@router.get("/farmer/{farmer_id}")
def get_farmer(farmer_id: str):
    farmer = fetch_one("SELECT * FROM farmers WHERE id = ?", (farmer_id,))
    if not farmer:
        raise HTTPException(status_code=404, detail="Farmer not found.")
    return {
        "farmer_id": farmer["id"],
        "name": farmer["name"],
        "mobile": farmer["mobile"],
        "village": farmer["village"],
        "district": farmer["district"],
        "verified": bool(farmer["verified"]),
    }


@router.get("/farmer/{farmer_id}/status")
def get_farmer_status(farmer_id: str):
    gate_pass = get_latest_gate_pass_for_farmer(farmer_id)
    if not gate_pass:
        raise HTTPException(status_code=404, detail="This farmer has no gate pass yet.")
    farmer = fetch_one("SELECT * FROM farmers WHERE id = ?", (farmer_id,))
    return {
        "gate_pass": format_gate_pass(gate_pass, farmer),
        "progress_timeline": build_progress_timeline(gate_pass["current_stage"]),
    }


@router.get("/farmer/{farmer_id}/queue")
def get_farmer_queue(farmer_id: str):
    gate_pass = get_latest_gate_pass_for_farmer(farmer_id)
    if not gate_pass:
        raise HTTPException(status_code=404, detail="This farmer has no gate pass yet.")
    return get_queue_info(gate_pass)


@router.get("/farmer/{farmer_id}/dashboard")
def get_farmer_dashboard(farmer_id: str):
    """Convenience endpoint: everything the farmer dashboard screen needs, in one call."""
    return build_farmer_dashboard(farmer_id)


# ===========================================================================
# 7. OFFICER DASHBOARD
# ===========================================================================

@router.get("/officer/farmers")
def get_officer_farmers(target_date: Optional[str] = None):
    """
    GET /officer/farmers?target_date=YYYY-MM-DD
    Returns the grid data for every farmer with a gate pass on that date.
    """
    target_date = target_date or today_str()

    rows = fetch_all(
        """SELECT gp.*, f.name as farmer_name, f.village as village
           FROM gate_passes gp
           JOIN farmers f ON f.id = gp.farmer_id
           WHERE gp.date = ?
           ORDER BY
             CASE WHEN gp.arrival_time IS NULL THEN 1 ELSE 0 END,
             gp.arrival_time ASC,
             gp.created_at ASC""",
        (target_date,),
    )

    grid = []
    for row in rows:
        queue_info = get_queue_info(row)
        grid.append({
            "farmer_id": row["farmer_id"],
            "farmer_name": row["farmer_name"],
            "village": row["village"],
            "gate_pass_id": row["id"],
            "estimated_weight": row["estimated_weight"],
            "current_stage": row["current_stage"],
            "current_stage_label": STAGE_LABELS.get(row["current_stage"], row["current_stage"]),
            "color": STAGE_COLORS.get(row["current_stage"], "grey"),
            "arrival_time": row["arrival_time"],
            "queue_position": queue_info["position"],
        })

    return {"date": target_date, "farmer_count": len(grid), "farmers": grid}


@router.get("/officer/dashboard")
def get_officer_dashboard(target_date: Optional[str] = None):
    """
    A richer summary view: capacity info + a count of farmers per stage,
    plus the same grid as /officer/farmers, all in one response.
    """
    target_date = target_date or today_str()

    capacity = get_capacity(target_date)
    farmers_data = get_officer_farmers(target_date)

    stage_counts = {stage: 0 for stage in STAGE_ORDER}
    for farmer in farmers_data["farmers"]:
        stage_counts[farmer["current_stage"]] = stage_counts.get(farmer["current_stage"], 0) + 1

    return {
        "date": target_date,
        "capacity": capacity,
        "stage_counts": stage_counts,
        "farmer_count": farmers_data["farmer_count"],
        "farmers": farmers_data["farmers"],
    }
