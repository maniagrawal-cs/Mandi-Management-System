"""
models.py
---------
Pydantic models describing the JSON bodies the frontend sends to us.
FastAPI uses these to automatically validate incoming requests and to
generate the interactive API docs at /docs.

We keep response shapes as plain Python dicts (built in routes.py) rather
than more Pydantic models, because the responses are simple and this keeps
the project easier for a beginner to follow end-to-end.
"""

from pydantic import BaseModel, Field


class FarmerRegisterRequest(BaseModel):
    """
    Used to 'claim' an already-existing, government-verified farmer record
    and set a login password for it. This does NOT create a new farmer -
    it only matches an existing one by name + mobile number.
    """
    name: str
    mobile: str
    government_id: str = Field(default="", description="Optional, extra verification field")
    password: str


class FarmerLoginRequest(BaseModel):
    mobile: str
    password: str


class OfficerLoginRequest(BaseModel):
    username: str
    password: str


class GatePassRequest(BaseModel):
    farmer_id: str
    date: str  # format: YYYY-MM-DD
    estimated_weight: float


class QRScanRequest(BaseModel):
    gate_pass_id: str  # this is exactly what is encoded inside the QR code


class CapacitySetRequest(BaseModel):
    """Optional helper endpoint for officers to configure a day's total capacity."""
    date: str
    total_capacity: float
