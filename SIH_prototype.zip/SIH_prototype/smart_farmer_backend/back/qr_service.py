"""
qr_service.py
-------------
Generates QR codes by calling a free external QR-code-generation API
(https://goqr.me/api/) instead of generating QR images ourselves.

HOW IT WORKS:
We don't need an API key. We just build a URL where the QR content is a
query parameter. That URL, when opened, returns a ready-made QR code PNG
image. We store that URL in the gate_passes.qr_url column and give it
straight to the frontend, which can display it with a plain <img> tag.

The actual data encoded INSIDE the QR code is simply the Gate Pass ID
(e.g. "GP1001"). When an officer scans it with any phone/QR scanner app,
the scanner will read out the text "GP1001". The frontend then sends that
text to POST /qr/scan, and the backend takes it from there.
"""

import urllib.parse

QR_API_BASE = "https://api.qrserver.com/v1/create-qr-code/"


def generate_qr_url(data: str, size: str = "250x250") -> str:
    """
    Build a URL that, when opened/loaded as an image, shows a QR code
    encoding `data`.

    Example:
        generate_qr_url("GP1001")
        -> "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=GP1001"
    """
    encoded_data = urllib.parse.quote(str(data))
    return f"{QR_API_BASE}?size={size}&data={encoded_data}"
