"""
stages.py
---------
This file defines the farmer's journey through the centre as a simple
ordered list. Everything about "what stage comes after what" lives here,
so changing the workflow later (e.g. adding a new checkpoint) only means
editing this one list.

HOW IT WORKS:
Each gate pass has a "current_stage". When an officer scans a farmer's QR
code, the backend looks at STAGE_ORDER, finds the current stage, and moves
the farmer to the very next one in the list. That's the whole "automatic
stage progression" logic.
"""

# The official order of the farmer's journey through the centre.
# Add/remove/reorder stages here - the rest of the app will follow automatically.
STAGE_ORDER = [
    "GATE_PASS_GENERATED",  # gate pass created, farmer has not arrived yet
    "ARRIVED",               # farmer scanned in at the gate
    "WEIGHT_CHECK",          # produce is being weighed
    "QUALITY_CHECK",         # produce quality is being checked
    "STORAGE",               # produce is being stored
    "PAYMENT",               # farmer is being paid
    "COMPLETED",             # entire process finished
]

# A simple colour code for each stage so the frontend can colour the
# officer's grid. The backend never draws anything - it just tells the
# frontend which colour "key" to use.
STAGE_COLORS = {
    "GATE_PASS_GENERATED": "yellow",   # waiting to arrive
    "ARRIVED": "blue",
    "WEIGHT_CHECK": "orange",
    "QUALITY_CHECK": "purple",
    "STORAGE": "green",
    "PAYMENT": "teal",
    "COMPLETED": "success",
    "CANCELLED": "red",
}

# Human friendly labels (used in dashboards / messages)
STAGE_LABELS = {
    "GATE_PASS_GENERATED": "Waiting to Arrive",
    "ARRIVED": "Arrived",
    "WEIGHT_CHECK": "Weight Check",
    "QUALITY_CHECK": "Quality Check",
    "STORAGE": "Storage",
    "PAYMENT": "Payment",
    "COMPLETED": "Completed",
    "CANCELLED": "Cancelled",
}


def get_stage_index(stage: str) -> int:
    """Return the position of a stage in STAGE_ORDER, or -1 if unknown."""
    return STAGE_ORDER.index(stage) if stage in STAGE_ORDER else -1


def get_next_stage(current_stage: str):
    """Return the stage that comes after current_stage, or None if it's the last one."""
    idx = get_stage_index(current_stage)
    if idx == -1 or idx + 1 >= len(STAGE_ORDER):
        return None
    return STAGE_ORDER[idx + 1]


def build_progress_timeline(current_stage: str):
    """
    Build a list like:
    [{"stage": "GATE_PASS_GENERATED", "label": "...", "status": "done"}, ...]
    status is one of: done / current / pending
    This is what the frontend uses to draw a progress bar.
    """
    current_idx = get_stage_index(current_stage)
    timeline = []
    for i, stage in enumerate(STAGE_ORDER):
        if i < current_idx:
            status = "done"
        elif i == current_idx:
            status = "current"
        else:
            status = "pending"
        timeline.append({
            "stage": stage,
            "label": STAGE_LABELS.get(stage, stage),
            "color": STAGE_COLORS.get(stage, "grey"),
            "status": status,
        })
    return timeline
