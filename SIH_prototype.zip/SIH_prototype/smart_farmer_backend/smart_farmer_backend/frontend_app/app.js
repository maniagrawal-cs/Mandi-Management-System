// ============================================================================
// KisanGate frontend — vanilla JS, no build step.
// Talks to the backend at API_BASE via fetch(). Run the backend first:
//   uvicorn main:app --reload
// then just open this index.html in a browser.
// ============================================================================

const API_BASE = "http://127.0.0.1:8000";

// Maps the backend's color keywords (see stages.STAGE_COLORS) to this
// design's stage colors, so the palette stays intentional instead of
// hard-coding hex values from the backend.
const STAGE_COLOR_MAP = {
  yellow: "var(--stage-waiting)",
  blue: "var(--stage-arrived)",
  orange: "var(--stage-weight)",
  purple: "var(--stage-quality)",
  green: "var(--stage-storage)",
  teal: "var(--stage-payment)",
  success: "var(--stage-completed)",
  red: "var(--stage-cancelled)",
  grey: "var(--ink-faint)",
};

const state = {
  farmerId: null,
  officerId: null,
};

// ---------------------------------------------------------------------------
// View / navigation
// ---------------------------------------------------------------------------

function showView(name) {
  document.querySelectorAll(".view").forEach((el) => el.classList.remove("is-active"));
  document.getElementById(`view-${name}`).classList.add("is-active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function goHome() {
  showView("landing");
}

function switchAuthTab(tab) {
  document.querySelectorAll(".tabs__btn").forEach((b) => b.classList.toggle("is-active", b.dataset.tab === tab));
  document.getElementById("farmerLoginForm").classList.toggle("is-hidden", tab !== "login");
  document.getElementById("farmerRegisterForm").classList.toggle("is-hidden", tab !== "register");
  hide("farmerAuthError");
}

function updateTopbarMeta() {
  const el = document.getElementById("topbarMeta");
  if (state.farmerId) el.textContent = `Signed in as farmer ${state.farmerId}`;
  else if (state.officerId) el.textContent = `Signed in as officer ${state.officerId}`;
  else el.textContent = "";
}

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function hide(id) { document.getElementById(id).classList.add("is-hidden"); }
function show(id) { document.getElementById(id).classList.remove("is-hidden"); }

function setError(id, message) {
  const el = document.getElementById(id);
  el.textContent = message;
  el.classList.remove("is-hidden");
}

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

function toast(message) {
  const el = document.getElementById("toast");
  el.textContent = message;
  el.classList.remove("is-hidden");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add("is-hidden"), 3200);
}

async function api(path, method = "GET", body = null) {
  let res, data;
  try {
    res = await fetch(API_BASE + path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : null,
    });
    data = await res.json();
  } catch (err) {
    throw new Error(`Can't reach the backend at ${API_BASE}. Is it running?`);
  }
  if (!res.ok) {
    throw new Error(data.detail || "Something went wrong.");
  }
  return data;
}

// ---------------------------------------------------------------------------
// Farmer: auth
// ---------------------------------------------------------------------------

async function handleFarmerLogin(evt) {
  evt.preventDefault();
  hide("farmerAuthError");
  const mobile = document.getElementById("loginMobile").value.trim();
  const password = document.getElementById("loginPassword").value;
  try {
    const dashboard = await api("/farmer/login", "POST", { mobile, password });
    state.farmerId = dashboard.farmer.farmer_id;
    updateTopbarMeta();
    renderFarmerDashboard(dashboard);
    showView("farmer-dashboard");
  } catch (err) {
    setError("farmerAuthError", err.message);
  }
  return false;
}

async function handleFarmerRegister(evt) {
  evt.preventDefault();
  hide("farmerAuthError");
  const body = {
    name: document.getElementById("regName").value.trim(),
    mobile: document.getElementById("regMobile").value.trim(),
    government_id: document.getElementById("regGovId").value.trim(),
    password: document.getElementById("regPassword").value,
  };
  try {
    await api("/farmer/register", "POST", body);
    toast("Registered! You can log in now.");
    switchAuthTab("login");
    document.getElementById("loginMobile").value = body.mobile;
  } catch (err) {
    setError("farmerAuthError", err.message);
  }
  return false;
}

function logoutFarmer() {
  state.farmerId = null;
  updateTopbarMeta();
  showView("landing");
}

// ---------------------------------------------------------------------------
// Farmer: dashboard
// ---------------------------------------------------------------------------

async function refreshFarmerDashboard() {
  try {
    const dashboard = await api(`/farmer/${state.farmerId}/dashboard`);
    renderFarmerDashboard(dashboard);
  } catch (err) {
    toast(err.message);
  }
}

function renderFarmerDashboard(dashboard) {
  const f = dashboard.farmer;
  document.getElementById("farmerName").textContent = f.name;
  document.getElementById("farmerMeta").textContent =
    `Farmer ID ${f.farmer_id} · ${f.village || "—"}${f.district ? ", " + f.district : ""}`;

  const gp = dashboard.gate_pass;

  if (!gp) {
    show("noGatePass");
    hide("hasGatePass");
    hide("progressPanel");
    hide("queuePanel");
    hide("scanPanel");
    document.getElementById("gpDate").value = todayStr();
    return;
  }

  hide("noGatePass");
  show("hasGatePass");

  document.getElementById("ticketId").textContent = gp.gate_pass_id;
  document.getElementById("ticketFarmer").textContent = f.name;
  document.getElementById("ticketDate").textContent = gp.date;
  document.getElementById("ticketWeight").textContent = `${gp.estimated_weight} kg`;
  document.getElementById("ticketStage").textContent = gp.current_stage_label;
  document.getElementById("ticketQr").src = gp.qr_url;

  show("progressPanel");
  renderRail(dashboard.progress_timeline);

  show("queuePanel");
  renderQueue(dashboard.queue);

  if (gp.current_stage !== "COMPLETED") {
    show("scanPanel");
  } else {
    hide("scanPanel");
  }
  hide("scanMessage");
}

function renderRail(timeline) {
  const rail = document.getElementById("progressRail");
  rail.innerHTML = "";
  timeline.forEach((step) => {
    const li = document.createElement("li");
    li.className = `rail__stop is-${step.status}`;
    li.innerHTML = `<span class="rail__dot"></span><span class="rail__label">${step.label}</span>`;
    rail.appendChild(li);
  });
}

function renderQueue(queue) {
  const el = document.getElementById("queueReadout");
  if (!queue || !queue.in_queue) {
    el.innerHTML = `<p class="queue-readout__empty">${queue ? queue.message : "No queue information yet."}</p>`;
    return;
  }
  el.innerHTML = `
    <div class="queue-readout__position">#${queue.position}</div>
    <p class="queue-readout__label">your position in today's queue</p>
    <div class="queue-readout__row"><span>Farmers ahead of you</span><span>${queue.farmers_ahead}</span></div>
    <div class="queue-readout__row"><span>Farmers waiting in total</span><span>${queue.farmers_waiting_total}</span></div>
  `;
}

async function handleCreateGatePass(evt) {
  evt.preventDefault();
  hide("gatePassError");
  const dateVal = document.getElementById("gpDate").value;
  const weight = parseFloat(document.getElementById("gpWeight").value);
  try {
    await api("/gate-pass", "POST", { farmer_id: state.farmerId, date: dateVal, estimated_weight: weight });
    toast("Gate pass approved.");
    await refreshFarmerDashboard();
  } catch (err) {
    setError("gatePassError", err.message);
  }
  return false;
}

async function simulateScan() {
  hide("scanMessage");
  try {
    const gp = await api(`/farmer/${state.farmerId}/status`);
    const gateId = gp.gate_pass.gate_pass_id;
    const result = await api("/qr/scan", "POST", { gate_pass_id: gateId });
    const msgEl = document.getElementById("scanMessage");
    msgEl.textContent = `Moved to: ${result.gate_pass.current_stage_label}`;
    msgEl.classList.remove("is-hidden");
    await refreshFarmerDashboard();
  } catch (err) {
    const msgEl = document.getElementById("scanMessage");
    msgEl.textContent = err.message;
    msgEl.classList.remove("is-hidden");
  }
}

// wire up date field default + auto-preview capacity as the farmer types
document.addEventListener("input", async (evt) => {
  if (evt.target.id === "gpDate" || evt.target.id === "gpWeight") {
    const dateVal = document.getElementById("gpDate").value;
    if (!dateVal) return;
    try {
      const cap = await api(`/capacity/${dateVal}`);
      const el = document.getElementById("capacityPreview");
      el.innerHTML = `${cap.remaining_capacity} kg remaining of ${cap.total_capacity} kg on ${cap.date}`;
      el.classList.remove("is-hidden");
    } catch (err) {
      // silently ignore preview errors
    }
  }
});

// ---------------------------------------------------------------------------
// Officer: auth
// ---------------------------------------------------------------------------

async function handleOfficerLogin(evt) {
  evt.preventDefault();
  hide("officerAuthError");
  const username = document.getElementById("officerUsername").value.trim();
  const password = document.getElementById("officerPassword").value;
  try {
    const officer = await api("/officer/login", "POST", { username, password });
    state.officerId = officer.officer_id;
    updateTopbarMeta();
    document.getElementById("officerName").textContent = officer.name;
    document.getElementById("officerMeta").textContent = `Officer ID ${officer.officer_id} · Centre ${officer.centre_id}`;
    document.getElementById("officerDate").value = todayStr();
    renderStageLegend();
    showView("officer-dashboard");
    loadOfficerDashboard();
  } catch (err) {
    setError("officerAuthError", err.message);
  }
  return false;
}

function logoutOfficer() {
  state.officerId = null;
  updateTopbarMeta();
  showView("landing");
}

// ---------------------------------------------------------------------------
// Officer: dashboard
// ---------------------------------------------------------------------------

function renderStageLegend() {
  const stages = [
    ["Waiting", "yellow"], ["Arrived", "blue"], ["Weight check", "orange"],
    ["Quality check", "purple"], ["Storage", "green"], ["Payment", "teal"], ["Completed", "success"],
  ];
  const el = document.getElementById("stageLegend");
  el.innerHTML = stages.map(([label, color]) =>
    `<span class="stage-legend__item"><span class="stage-legend__dot" style="background:${STAGE_COLOR_MAP[color]}"></span>${label}</span>`
  ).join("");
}

async function loadOfficerDashboard() {
  const dateVal = document.getElementById("officerDate").value || todayStr();
  try {
    const data = await api(`/officer/dashboard?target_date=${dateVal}`);
    renderSilo(data.capacity);
    renderLedger(data.farmers);
  } catch (err) {
    toast(err.message);
  }
}

function renderSilo(capacity) {
  const pct = capacity.total_capacity > 0
    ? Math.min(100, Math.round((capacity.allocated_capacity / capacity.total_capacity) * 100))
    : 0;
  document.getElementById("siloFill").style.height = `${pct}%`;
  document.getElementById("siloReading").textContent = `${pct}%`;
  document.getElementById("siloSub").textContent =
    `${capacity.allocated_capacity.toLocaleString()} / ${capacity.total_capacity.toLocaleString()} kg booked`;
}

function renderLedger(farmers) {
  const body = document.getElementById("ledgerBody");
  body.innerHTML = "";
  document.getElementById("farmerCount").textContent = `${farmers.length} farmer${farmers.length === 1 ? "" : "s"}`;

  if (farmers.length === 0) {
    show("ledgerEmpty");
    return;
  }
  hide("ledgerEmpty");

  farmers.forEach((f) => {
    const tr = document.createElement("tr");
    const canScan = f.current_stage !== "COMPLETED";
    tr.innerHTML = `
      <td class="ledger__queue">${f.queue_position ?? "—"}</td>
      <td><div class="ledger__farmer-name">${f.farmer_name}</div><div class="ledger__farmer-id">${f.farmer_id}</div></td>
      <td>${f.gate_pass_id}</td>
      <td>${f.estimated_weight} kg</td>
      <td><span class="stage-pill" style="background:${STAGE_COLOR_MAP[f.color] || "var(--ink-faint)"}">${f.current_stage_label}</span></td>
      <td>${canScan ? `<button class="ledger__scan-btn" onclick="scanFromLedger('${f.gate_pass_id}')">Scan →</button>` : ""}</td>
    `;
    body.appendChild(tr);
  });
}

async function scanFromLedger(gatePassId) {
  try {
    const result = await api("/qr/scan", "POST", { gate_pass_id: gatePassId });
    toast(`${result.farmer_name}: moved to ${result.gate_pass.current_stage_label}`);
    await loadOfficerDashboard();
  } catch (err) {
    toast(err.message);
  }
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

document.getElementById("apiBaseLabel").textContent = API_BASE;
showView("landing");
